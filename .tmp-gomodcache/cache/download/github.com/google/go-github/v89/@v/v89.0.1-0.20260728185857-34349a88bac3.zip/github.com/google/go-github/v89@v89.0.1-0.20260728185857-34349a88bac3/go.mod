module github.com/google/go-github/v89

go 1.25.0

require (
	github.com/google/go-cmp v0.7.0
	github.com/google/go-querystring v1.2.0
)
