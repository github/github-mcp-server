// Copyright 2013 The go-github AUTHORS. All rights reserved.
//
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package github

import (
	"context"
	"fmt"
	"time"
)

// IssueComment represents a comment left on an issue.
type IssueComment struct {
	ID        *int64     `json:"id,omitempty"`
	NodeID    *string    `json:"node_id,omitempty"`
	Body      *string    `json:"body,omitempty"`
	User      *User      `json:"user,omitempty"`
	Reactions *Reactions `json:"reactions,omitempty"`
	CreatedAt *Timestamp `json:"created_at,omitempty"`
	UpdatedAt *Timestamp `json:"updated_at,omitempty"`
	// AuthorAssociation is the comment author's relationship to the issue's repository.
	// Possible values are "COLLABORATOR", "CONTRIBUTOR", "FIRST_TIMER", "FIRST_TIME_CONTRIBUTOR", "MEMBER", "OWNER", or "NONE".
	//
	// Deprecated: GitHub will remove this field from Events API payloads on October 7, 2025.
	// Use the Issue Comments REST API endpoint to retrieve this information.
	// See: https://docs.github.com/rest/issues/comments?apiVersion=2022-11-28#get-an-issue-comment
	AuthorAssociation *string `json:"author_association,omitempty"`
	URL               *string `json:"url,omitempty"`
	HTMLURL           *string `json:"html_url,omitempty"`
	IssueURL          *string `json:"issue_url,omitempty"`
}

func (i IssueComment) String() string {
	return Stringify(i)
}

// IssueListCommentsOptions specifies the optional parameters to the
// IssuesService.ListComments method.
type IssueListCommentsOptions struct {
	// Sort specifies how to sort comments. Possible values are: created, updated.
	Sort *string `url:"sort,omitempty"`

	// Direction in which to sort comments. Possible values are: asc, desc.
	Direction *string `url:"direction,omitempty"`

	// Since filters comments by time.
	Since *time.Time `url:"since,omitempty"`

	ListOptions
}

// ListComments lists all comments on the specified issue. Specifying an issue
// number of 0 will return all comments on all issues for the repository.
//
// GitHub API docs: https://docs.github.com/rest/issues/comments?apiVersion=2022-11-28#list-issue-comments
//
// GitHub API docs: https://docs.github.com/rest/issues/comments?apiVersion=2022-11-28#list-issue-comments-for-a-repository
//
//meta:operation GET /repos/{owner}/{repo}/issues/comments
//meta:operation GET /repos/{owner}/{repo}/issues/{issue_number}/comments
func (s *IssuesService) ListComments(ctx context.Context, owner, repo string, number int, opts *IssueListCommentsOptions) ([]*IssueComment, *Response, error) {
	var u string
	if number == 0 {
		u = fmt.Sprintf("repos/%v/%v/issues/comments", owner, repo)
	} else {
		u = fmt.Sprintf("repos/%v/%v/issues/%v/comments", owner, repo, number)
	}
	u, err := addOptions(u, opts)
	if err != nil {
		return nil, nil, err
	}

	req, err := s.client.NewRequest(ctx, "GET", u, nil)
	if err != nil {
		return nil, nil, err
	}

	req.Header.Set("Accept", mediaTypeReactionsPreview)

	var comments []*IssueComment
	resp, err := s.client.Do(req, &comments)
	if err != nil {
		return nil, resp, err
	}

	return comments, resp, nil
}

// GetComment fetches the specified issue comment.
//
// GitHub API docs: https://docs.github.com/rest/issues/comments?apiVersion=2022-11-28#get-an-issue-comment
//
//meta:operation GET /repos/{owner}/{repo}/issues/comments/{comment_id}
func (s *IssuesService) GetComment(ctx context.Context, owner, repo string, commentID int64) (*IssueComment, *Response, error) {
	u := fmt.Sprintf("repos/%v/%v/issues/comments/%v", owner, repo, commentID)

	req, err := s.client.NewRequest(ctx, "GET", u, nil)
	if err != nil {
		return nil, nil, err
	}

	req.Header.Set("Accept", mediaTypeReactionsPreview)

	var comment *IssueComment
	resp, err := s.client.Do(req, &comment)
	if err != nil {
		return nil, resp, err
	}

	return comment, resp, nil
}

// CreateComment creates a new comment on the specified issue.
//
// GitHub API docs: https://docs.github.com/rest/issues/comments?apiVersion=2022-11-28#create-an-issue-comment
//
//meta:operation POST /repos/{owner}/{repo}/issues/{issue_number}/comments
func (s *IssuesService) CreateComment(ctx context.Context, owner, repo string, number int, body *IssueComment) (*IssueComment, *Response, error) {
	u := fmt.Sprintf("repos/%v/%v/issues/%v/comments", owner, repo, number)
	req, err := s.client.NewRequest(ctx, "POST", u, body)
	if err != nil {
		return nil, nil, err
	}
	var c *IssueComment
	resp, err := s.client.Do(req, &c)
	if err != nil {
		return nil, resp, err
	}

	return c, resp, nil
}

// EditComment updates an issue comment.
// A non-nil comment.Body must be provided. Other comment fields should be left nil.
//
// GitHub API docs: https://docs.github.com/rest/issues/comments?apiVersion=2022-11-28#update-an-issue-comment
//
//meta:operation PATCH /repos/{owner}/{repo}/issues/comments/{comment_id}
func (s *IssuesService) EditComment(ctx context.Context, owner, repo string, commentID int64, body *IssueComment) (*IssueComment, *Response, error) {
	u := fmt.Sprintf("repos/%v/%v/issues/comments/%v", owner, repo, commentID)
	req, err := s.client.NewRequest(ctx, "PATCH", u, body)
	if err != nil {
		return nil, nil, err
	}
	var c *IssueComment
	resp, err := s.client.Do(req, &c)
	if err != nil {
		return nil, resp, err
	}

	return c, resp, nil
}

// DeleteComment deletes an issue comment.
//
// GitHub API docs: https://docs.github.com/rest/issues/comments?apiVersion=2022-11-28#delete-an-issue-comment
//
//meta:operation DELETE /repos/{owner}/{repo}/issues/comments/{comment_id}
func (s *IssuesService) DeleteComment(ctx context.Context, owner, repo string, commentID int64) (*Response, error) {
	u := fmt.Sprintf("repos/%v/%v/issues/comments/%v", owner, repo, commentID)
	req, err := s.client.NewRequest(ctx, "DELETE", u, nil)
	if err != nil {
		return nil, err
	}
	return s.client.Do(req, nil)
}
