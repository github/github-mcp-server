// Copyright 2023 The go-github AUTHORS. All rights reserved.
//
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package github

import (
	"context"
	"fmt"
)

// HookConfig describes metadata about a webhook configuration.
type HookConfig struct {
	// The media type used to serialize the payloads
	// Possible values are `json` and `form`, the field is not specified the default is `form`
	ContentType *string `json:"content_type,omitempty"`
	// The possible values are 0 and 1.
	// Setting it to 1 will allow skipping certificate verification for the host,
	// potentially exposing to MitM attacks: https://en.wikipedia.org/wiki/Man-in-the-middle_attack
	InsecureSSL *string `json:"insecure_ssl,omitempty"`
	URL         *string `json:"url,omitempty"`

	// Secret is returned obfuscated by GitHub, but it can be set for outgoing requests.
	Secret *string `json:"secret,omitempty"`
}

// GetHookConfiguration returns the configuration for the specified repository webhook.
//
// GitHub API docs: https://docs.github.com/rest/repos/webhooks?apiVersion=2022-11-28#get-a-webhook-configuration-for-a-repository
//
//meta:operation GET /repos/{owner}/{repo}/hooks/{hook_id}/config
func (s *RepositoriesService) GetHookConfiguration(ctx context.Context, owner, repo string, id int64) (*HookConfig, *Response, error) {
	u := fmt.Sprintf("repos/%v/%v/hooks/%v/config", owner, repo, id)
	req, err := s.client.NewRequest(ctx, "GET", u, nil)
	if err != nil {
		return nil, nil, err
	}

	var config *HookConfig
	resp, err := s.client.Do(req, &config)
	if err != nil {
		return nil, resp, err
	}

	return config, resp, nil
}

// UpdateHookConfiguration updates the configuration for the specified repository webhook.
//
// GitHub API docs: https://docs.github.com/rest/repos/webhooks?apiVersion=2022-11-28#update-a-webhook-configuration-for-a-repository
//
//meta:operation PATCH /repos/{owner}/{repo}/hooks/{hook_id}/config
func (s *RepositoriesService) UpdateHookConfiguration(ctx context.Context, owner, repo string, id int64, body HookConfig) (*HookConfig, *Response, error) {
	u := fmt.Sprintf("repos/%v/%v/hooks/%v/config", owner, repo, id)
	req, err := s.client.NewRequest(ctx, "PATCH", u, body)
	if err != nil {
		return nil, nil, err
	}

	var c *HookConfig
	resp, err := s.client.Do(req, &c)
	if err != nil {
		return nil, resp, err
	}

	return c, resp, nil
}
