// Copyright 2013 The go-github AUTHORS. All rights reserved.
//
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package github

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
)

// RepositoryListForksOptions specifies the optional parameters to the
// RepositoriesService.ListForks method.
type RepositoryListForksOptions struct {
	// How to sort the forks list. Possible values are: newest, oldest,
	// watchers. Default is "newest".
	Sort string `url:"sort,omitempty"`

	ListOptions
}

// ListForks lists the forks of the specified repository.
//
// GitHub API docs: https://docs.github.com/rest/repos/forks?apiVersion=2022-11-28#list-forks
//
//meta:operation GET /repos/{owner}/{repo}/forks
func (s *RepositoriesService) ListForks(ctx context.Context, owner, repo string, opts *RepositoryListForksOptions) ([]*Repository, *Response, error) {
	u := fmt.Sprintf("repos/%v/%v/forks", owner, repo)
	u, err := addOptions(u, opts)
	if err != nil {
		return nil, nil, err
	}

	req, err := s.client.NewRequest(ctx, "GET", u, nil)
	if err != nil {
		return nil, nil, err
	}

	req.Header.Set("Accept", mediaTypeTopicsPreview)

	var repos []*Repository
	resp, err := s.client.Do(req, &repos)
	if err != nil {
		return nil, resp, err
	}

	return repos, resp, nil
}

// RepositoryCreateForkOptions specifies the optional parameters to the
// RepositoriesService.CreateFork method.
type RepositoryCreateForkOptions struct {
	// The organization to fork the repository into.
	Organization      string `json:"organization,omitempty"`
	Name              string `json:"name,omitempty"`
	DefaultBranchOnly bool   `json:"default_branch_only,omitempty"`
}

// CreateFork creates a fork of the specified repository.
//
// This method might return an *AcceptedError and a status code of
// 202. This is because this is the status that GitHub returns to signify that
// it is now computing creating the fork in a background task. In this event,
// the Repository value will be returned, which includes the details about the pending fork.
// A follow up request, after a delay of a second or so, should result
// in a successful request.
//
// GitHub API docs: https://docs.github.com/rest/repos/forks?apiVersion=2022-11-28#create-a-fork
//
//meta:operation POST /repos/{owner}/{repo}/forks
func (s *RepositoriesService) CreateFork(ctx context.Context, owner, repo string, body *RepositoryCreateForkOptions) (*Repository, *Response, error) {
	u := fmt.Sprintf("repos/%v/%v/forks", owner, repo)

	req, err := s.client.NewRequest(ctx, "POST", u, body)
	if err != nil {
		return nil, nil, err
	}

	var fork *Repository
	resp, err := s.client.Do(req, &fork)
	if err != nil {
		// Persist AcceptedError's metadata to the Repository object.
		var aerr *AcceptedError
		if errors.As(err, &aerr) {
			if err := json.Unmarshal(aerr.Raw, &fork); err != nil {
				return fork, resp, err
			}

			return fork, resp, err
		}
		return nil, resp, err
	}

	return fork, resp, nil
}
