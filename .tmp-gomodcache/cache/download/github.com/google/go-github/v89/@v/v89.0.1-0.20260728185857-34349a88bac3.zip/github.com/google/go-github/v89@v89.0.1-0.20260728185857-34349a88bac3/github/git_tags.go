// Copyright 2013 The go-github AUTHORS. All rights reserved.
//
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package github

import (
	"context"
	"fmt"
)

// Tag represents a tag object.
type Tag struct {
	Tag          *string                `json:"tag,omitempty"`
	SHA          *string                `json:"sha,omitempty"`
	URL          *string                `json:"url,omitempty"`
	Message      *string                `json:"message,omitempty"`
	Tagger       *CommitAuthor          `json:"tagger,omitempty"`
	Object       *GitObject             `json:"object,omitempty"`
	Verification *SignatureVerification `json:"verification,omitempty"`
	NodeID       *string                `json:"node_id,omitempty"`
}

// CreateTag represents the payload for creating a tag.
type CreateTag struct {
	Tag     string        `json:"tag,omitempty"`
	Message string        `json:"message,omitempty"`
	Object  string        `json:"object,omitempty"`
	Type    string        `json:"type,omitempty"`
	Tagger  *CommitAuthor `json:"tagger,omitempty"`
}

// GetTag fetches a tag from a repo given a SHA.
//
// GitHub API docs: https://docs.github.com/rest/git/tags?apiVersion=2022-11-28#get-a-tag
//
//meta:operation GET /repos/{owner}/{repo}/git/tags/{tag_sha}
func (s *GitService) GetTag(ctx context.Context, owner, repo, sha string) (*Tag, *Response, error) {
	u := fmt.Sprintf("repos/%v/%v/git/tags/%v", owner, repo, sha)
	req, err := s.client.NewRequest(ctx, "GET", u, nil)
	if err != nil {
		return nil, nil, err
	}

	var tag *Tag
	resp, err := s.client.Do(req, &tag)
	if err != nil {
		return nil, resp, err
	}

	return tag, resp, nil
}

// CreateTag creates a tag object.
//
// GitHub API docs: https://docs.github.com/rest/git/tags?apiVersion=2022-11-28#create-a-tag-object
//
//meta:operation POST /repos/{owner}/{repo}/git/tags
func (s *GitService) CreateTag(ctx context.Context, owner, repo string, body CreateTag) (*Tag, *Response, error) {
	u := fmt.Sprintf("repos/%v/%v/git/tags", owner, repo)

	req, err := s.client.NewRequest(ctx, "POST", u, body)
	if err != nil {
		return nil, nil, err
	}

	var t *Tag
	resp, err := s.client.Do(req, &t)
	if err != nil {
		return nil, resp, err
	}

	return t, resp, nil
}
